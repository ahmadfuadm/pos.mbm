<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'failed' => 'Nama Pengguna & Kata Sandi Tidak Terdapat pada Database Umkm Pos.',
    'throttle' => 'Terlalu banyak upaya masuk. Silakan coba lagi dalam beberapa :seconds seconds.',

];
